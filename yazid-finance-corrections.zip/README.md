# 👋 Bienvenue sur le portfolio de Yazid

**Étudiant en sciences économiques et de gestion (L2) | Finance de marché | Analyse financière | Données et investissement**

> Transformer les données financières en informations utiles pour mieux comprendre les marchés, analyser les entreprises et éclairer les décisions d’investissement.

Je suis étudiant en deuxième année de sciences économiques et de gestion à la **FASEG de l’Université de Kara, au Togo**. Je développe progressivement des compétences en analyse financière, marchés financiers, gestion de portefeuille et analyse de données.

Mon objectif est de construire un parcours professionnel à l’intersection de la finance, de la technologie et de la donnée, avec un intérêt particulier pour le développement des marchés financiers africains.

## 🎯 Objectifs professionnels
- Développer une expertise en analyse des marchés financiers.
- Renforcer mes compétences en analyse des investissements et en gestion de portefeuille.
- Utiliser les méthodes quantitatives pour étudier le risque et la performance.
- Réaliser des projets pratiques avec Python, Excel et des données financières.
- Poursuivre mes études en master dans le domaine de la finance de marché et de l’investissement.

## 🧰 Compétences et outils en développement

| Domaine | Compétences et outils |
|---|---|
| Programmation | Python |
| Analyse de données | Pandas, NumPy |
| Visualisation | Matplotlib |
| Tableurs | Microsoft Excel |
| Finance | Analyse financière, analyse des investissements |
| Finance quantitative | Rendement, risque, volatilité, théorie du portefeuille |
| Marchés | Price Action, Smart Money Concepts, Fibonacci |
| Économie | Microéconomie, macroéconomie |

*Ces compétences sont en cours d’acquisition et de consolidation à travers mes études et mes travaux pratiques.*

## 📊 Projets
Les projets ci-dessous constituent mon programme de travail. Les pages détaillées présenteront progressivement les données utilisées, la méthodologie, les calculs, les résultats et leur interprétation. Un projet annoncé n’est pas nécessairement déjà achevé.

1. **[Construction et optimisation d’un portefeuille d’investissement](projects/portfolio-optimization/)** — rendement, risque, corrélations et allocation d’actifs.
2. **[Analyse financière d’entreprises cotées à la BRVM](projects/analyse-brvm/)** — états financiers, ratios, rentabilité et capacité d’autofinancement.
3. **[Analyse et backtesting d’une stratégie de trading](projects/backtesting-trading/)** — règles de stratégie, gestion du risque et évaluation historique.
4. **[Python appliqué à l’analyse des données financières](projects/python-finance/)** — traitement de données, calculs et visualisations.

👉 **[Consulter le portfolio en ligne](https://yazidsamari17-lgtm.github.io/Yazid-finance/)**

## 📚 Apprentissages en cours
- Mathématiques financières et méthodes quantitatives.
- Statistiques et analyse de données.
- Comptabilité, analyse financière et finance d’entreprise.
- Python pour l’analyse de données.
- Théorie du portefeuille et marchés financiers.

## 🌍 Intérêt pour la finance africaine
Je m’intéresse à la manière dont la technologie, l’innovation financière et l’analyse des données peuvent contribuer au développement économique de l’Afrique. Je souhaite notamment approfondir ma compréhension des marchés financiers de la région, dont la BRVM.

## 🤝 Contact et collaboration
Je suis ouvert aux opportunités d’apprentissage, stages, collaborations académiques, projets de recherche financière et échanges professionnels.

- **GitHub :** [yazidsamari17-lgtm](https://github.com/yazidsamari17-lgtm)
- **Portfolio :** [Yazid Finance](https://yazidsamari17-lgtm.github.io/Yazid-finance/)
- **Localisation :** Kara, Togo
- **Langues :** Français ; anglais en apprentissage

---
*« Ne pas seulement étudier les marchés financiers : apprendre à les analyser, à comprendre leurs mécanismes et à produire des analyses rigoureuses. »*
