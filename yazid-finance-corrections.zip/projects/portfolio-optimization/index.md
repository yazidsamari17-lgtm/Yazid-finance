# Construction et optimisation d’un portefeuille d’investissement

**Domaine :** Gestion de portefeuille et finance quantitative  
**Outils envisagés :** Python, Pandas, NumPy, Matplotlib et Excel  
**Statut :** Projet à réaliser

## Objectif
Construire un portefeuille composé de plusieurs actifs, puis étudier le compromis entre rendement et risque. Le projet permettra de mettre en pratique les notions de diversification et les bases de la théorie moderne du portefeuille.

## Questions étudiées
- Quel rendement historique chaque actif a-t-il généré ?
- Quel est son niveau de volatilité ?
- Comment les actifs évoluent-ils les uns par rapport aux autres ?
- La diversification réduit-elle le risque du portefeuille ?
- Comment comparer différentes allocations ?

## Méthodologie prévue
1. Choisir un univers d’actifs et une période d’observation.
2. Collecter et documenter les données de prix.
3. Nettoyer les données et calculer les rendements.
4. Mesurer rendement moyen, volatilité et corrélations.
5. Construire plusieurs allocations et calculer leurs indicateurs.
6. Comparer les résultats en tenant compte des limites des données.

## Indicateurs
Rendement, volatilité, matrice de corrélation, poids des actifs, rendement du portefeuille et ratio de Sharpe lorsque les données nécessaires sont disponibles.

## Données et résultats
Les sources de données, hypothèses, calculs, graphiques et résultats seront ajoutés après réalisation. Aucun résultat n’est présenté à ce stade.

## Limites
Les performances historiques ne garantissent pas les performances futures. Les frais, la liquidité, les devises et la qualité des données devront être pris en compte selon l’univers retenu.
