# Analyse financière d’entreprises cotées à la BRVM

**Domaine :** Analyse financière et investissement  
**Outils envisagés :** Excel et Python  
**Statut :** Projet à réaliser

## Objectif
Étudier la situation financière et la performance d’une entreprise cotée à la Bourse régionale des valeurs mobilières (BRVM), à partir de ses états financiers publiés.

## Axes d’analyse
- Activité et évolution du chiffre d’affaires.
- Rentabilité économique et financière.
- Structure financière et niveau d’endettement.
- Liquidité et capacité à honorer les engagements.
- Capacité d’autofinancement (CAF).
- Évolution des principaux indicateurs sur plusieurs exercices.

## Méthodologie prévue
1. Sélectionner une société cotée et définir la période d’étude.
2. Collecter les rapports annuels et états financiers officiels.
3. Vérifier les unités, périodes et conventions comptables.
4. Calculer les soldes et ratios pertinents.
5. Comparer les indicateurs dans le temps.
6. Interpréter les résultats et présenter les limites de l’analyse.

## Indicateurs envisagés
Chiffre d’affaires, résultat net, CAF, ROE, ROA, ratios d’endettement, ratios de liquidité et marges. Les formules retenues seront explicitées dans le rapport final.

## Sources et résultats
Les documents de référence, calculs, tableaux, graphiques et conclusions seront ajoutés après sélection de l’entreprise et réalisation des travaux.

## Précaution d’interprétation
Un ratio isolé ne suffit pas à juger une entreprise. L’analyse devra tenir compte du secteur, de la taille de l’entreprise, de son évolution et des éventuels éléments exceptionnels.
