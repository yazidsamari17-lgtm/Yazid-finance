# Python appliqué à l’analyse des données financières

**Domaine :** Programmation et analyse de données  
**Outils envisagés :** Python, Pandas, NumPy et Matplotlib  
**Statut :** Projet à réaliser

## Objectif
Utiliser Python pour automatiser des calculs financiers, traiter des jeux de données et produire des visualisations utiles à l’analyse.

## Travaux envisagés
- Importation de fichiers CSV et Excel.
- Nettoyage et contrôle de cohérence des données.
- Calcul de variations et de rendements.
- Statistiques descriptives.
- Calcul d’indicateurs financiers.
- Création de graphiques et de tableaux de synthèse.

## Méthodologie prévue
1. Choisir un jeu de données documenté.
2. Décrire les variables et les unités.
3. Nettoyer les valeurs manquantes ou incohérentes.
4. Réaliser les calculs avec des scripts reproductibles.
5. Visualiser les résultats.
6. Expliquer les résultats et les limites.

## Livrables attendus
Code Python commenté, jeu de données ou lien vers sa source, instructions d’exécution, tableaux, graphiques et courte interprétation.

## Résultats
Les notebooks, scripts et résultats seront ajoutés au fur et à mesure de la réalisation du projet.
