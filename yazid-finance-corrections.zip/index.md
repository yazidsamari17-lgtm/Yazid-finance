---
---

# Bienvenue sur mon portfolio

**Finance de marché · Analyse financière · Gestion de portefeuille · Analyse de données**

Je suis étudiant en deuxième année de sciences économiques et de gestion à la FASEG, Université de Kara (Togo). Ce site rassemble mes travaux pratiques, mes analyses et les compétences que je développe pour évoluer dans les métiers de la finance.

Mon objectif : apprendre à exploiter les données, mesurer le risque, analyser les entreprises et comprendre le fonctionnement des marchés financiers, avec un intérêt particulier pour l’Afrique.

## Mes domaines d’intérêt
- **Analyse financière :** comprendre la rentabilité, la structure financière et la performance des entreprises.
- **Finance de marché :** étudier les actifs financiers, les rendements et les risques.
- **Gestion de portefeuille :** analyser les corrélations et réfléchir à l’allocation des actifs.
- **Analyse de données :** utiliser Excel et Python pour traiter, calculer et visualiser des données.

## Mes projets

### [Construction et optimisation d’un portefeuille](projects/portfolio-optimization/)
Étudier le rendement, le risque, la volatilité et la diversification d’un portefeuille.

### [Analyse financière – BRVM](projects/analyse-brvm/)
Analyser les états financiers et les indicateurs de performance d’entreprises cotées à la BRVM.

### [Backtesting d’une stratégie de trading](projects/backtesting-trading/)
Formaliser une stratégie, tester ses règles sur des données historiques et mesurer ses performances.

### [Python pour la finance](projects/python-finance/)
Développer des outils simples de traitement, de calcul et de visualisation de données financières.

> **État d’avancement :** ces pages servent de cadres de travail. Les résultats et conclusions seront ajoutés au fur et à mesure de la réalisation effective des analyses.

## Outils et compétences
Python · Pandas · NumPy · Matplotlib · Excel · Analyse financière · Statistiques · Théorie du portefeuille

## À propos
Retrouve mon parcours, mes objectifs et mes compétences sur le [README du dépôt GitHub](https://github.com/yazidsamari17-lgtm/Yazid-finance).

[Voir mon profil GitHub](https://github.com/yazidsamari17-lgtm)
